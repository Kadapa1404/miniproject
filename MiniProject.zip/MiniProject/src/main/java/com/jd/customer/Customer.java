package com.jd.customer;

public class Customer {

	private int customerReference;
	private String customerName;
	private String addressLine1;
	private String addressLine2;
	private String town;
	private String country;
	private String postcode;
	public int getCustomerReference() {
		return customerReference;
	}
	public void setCustomerReference(int customerReference) {
		this.customerReference = customerReference;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getTown() {
		return town;
	}
	public void setTown(String town) {
		this.town = town;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPostcode() {
		return postcode;
	}
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	@Override
	public String toString() {
		return "Customer [customerReference=" + customerReference + ", customerName=" + customerName + ", addressLine1="
				+ addressLine1 + ", addressLine2=" + addressLine2 + ", town=" + town + ", country=" + country
				+ ", postcode=" + postcode + "]";
	}
	public Customer(int customerReference, String customerName, String addressLine1, String addressLine2, String town,
			String country, String postcode) {
		super();
		this.customerReference = customerReference;
		this.customerName = customerName;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.town = town;
		this.country = country;
		this.postcode = postcode;
	}
	
	
}
