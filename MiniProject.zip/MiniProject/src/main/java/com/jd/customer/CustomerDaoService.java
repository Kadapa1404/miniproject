package com.jd.customer;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
//import java.sql.*;

@Component
public class CustomerDaoService {

	
	  public static int customerCount=5;
	  
	  
	  private static List<Customer> customers=new ArrayList<>(); 
	  static {
	  customers.add(new Customer(1, "Sudhakar","Newbury Park",
	  "Ilford","London","UK","IG2 7LD")); customers.add(new Customer(2,
	  "Lakshmi","East Ham", "New Ham","London","UK","E6")); customers.add(new
	  Customer(3, "Akarsh","Gantshill", "Ilford","London","UK","I6"));
	  customers.add(new Customer(4, "Akarsha","Leyton",
	  "Redbridge","London","UK","E10")); customers.add(new Customer(5,
	  "Mully","Newbury Park", "Ilford","London","UK","RM6")); }
	 
	public List<Customer> findAll()  
	{  
		
	return customers;  
	}  

	public Customer save(Customer customer)  
	{  
	if(customer.getCustomerReference()==0)
	{  

	customer.setCustomerReference(++customerCount);  
	}  
	customers.add(customer);  
	return customer;  
	}  

	public Customer findOne(int id)  
	{  
	for(Customer customer:customers)  
	{  
	if(customer.getCustomerReference()==id)  
	return customer;  
	}  
	return null;  
	} 
}
